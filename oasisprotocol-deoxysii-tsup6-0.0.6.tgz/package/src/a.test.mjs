import * as deoxysii from './deoxysii';
console.log('star', deoxysii.AEAD)

import deoxysiiDefault from './deoxysii';
console.log('default', deoxysiiDefault.AEAD)

import {AEAD} from './deoxysii';
console.log('AEAD', AEAD)

import { expect, test } from "vitest";

test("a", () => {
});